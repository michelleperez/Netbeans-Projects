package swdeber6;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.427642E4-1A4A-D452-9654-438510BC53B5]
// </editor-fold> 
public interface Contrato {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.8BEA91D4-C242-C5DD-6C6F-024B2E389E61]
    // </editor-fold> 
    public float CalcularSueldo ();

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.A00C0972-6322-7BA8-1578-4CE24FB83A1F]
    // </editor-fold> 
    public void Mostrar ();

}

