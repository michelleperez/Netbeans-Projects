/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util.perez;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author michelle
 */
public class util {
     private InputStreamReader isr = new InputStreamReader (System.in);
    
    private BufferedReader br = new BufferedReader (isr);


    private String title;
    private String description;
    private Calendar date;
    private byte number;

    private Unit unit;

    public util() {
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDate(Calendar date) {
        this.date = date;
    }

    public void setNumber(byte number) {
        this.number = number;
    }

    public void setUnit(Unit unit) {
        this.unit = unit;
    }
    
    public void Print (String text){
        System.out.print(text);
    }

    public void Println (String text){
        System.out.println(text);
    }
    
    
    public String ReadString (String message) throws IOException{
        Print (message); // mensaje
        String str = br.readLine(); // lectura
        return str;
        
    }
        public char ReadChar (String message) throws IOException{
        Print (message); // mensaje
        char str = (char) br.read(); // lectura
        return str;
        
    }

    public byte ReadByte (String message, byte min, byte max )throws IOException{
       byte result = 0;
       String str;
           while(true){
    try{
        Print(message);
        str = br.readLine();
        result=Byte.parseByte(str);
        
        if(result > max){
            IOException io = new IOException("Valor superior");
            throw io;
        }
        if(result< min){
            IOException io = new IOException("Valor inferior al límite");
        }
        break;
    }catch  (IOException | NumberFormatException  e){
        Println("El valor no es valido");
        
    }
}
       return result;
     
    }
    
    public int ReadInt (String message )throws IOException{
       int result = 0;
       String str;
           while(true){
    try{
        Print(message);
        str = br.readLine();
        result=Integer.parseInt(str);
        break;
    }catch  (IOException | NumberFormatException  e){
        Println("El valor no es valido");
        
    }
}
       return  result;
     
 }
      public short ReadShort (String message )throws IOException{
       short result = 0;
       String str;
           while(true){
    try{
        Print(message);
        str = br.readLine();
        result=Short.parseShort(str);
        break;
    }catch  (IOException | NumberFormatException  e){
        Println("El valor no es valido");
        
    }
}
       return  result;
     
 }  
 public long ReadLong  (String message )throws IOException{
       long  result = 0;
       String str;
           while(true){
    try{
        Print(message);
        str = br.readLine();
        result=Long.parseLong(str);
        break;
    }catch  (IOException | NumberFormatException  e){
        Println("El valor no es valido");
        
    }
}
       return  result;
     
 }  
 
  public float ReadFloat  (String message )throws IOException{
       float  result = 0;
       String str;
           while(true){
    try{
        Print(message);
        str = br.readLine();
        result=Float.parseFloat(str);
        break;
    }catch  (IOException | NumberFormatException  e){
        Println("El valor no es válido");
        
    }
}
       return  result;  
 } 
   public double ReadDouble  (String message )throws IOException{
       double  result = 0;
       String str;
           while(true){
    try{
        Print(message);
        str = br.readLine();
        result=Double.parseDouble(str);
        break;
    }catch  (IOException | NumberFormatException  e){
        Println("El valor no es válido");
        
    }
}
       return  result;  
 }  
   
    
    public void PrintHeader(){
        
    }
    public void PrintFoother(){
        
    }
    public int GetYear(Calendar dateBorn){
        int result = 0;
        Calendar current = Calendar.getInstance();
        int year = current.get(Calendar.YEAR) - date.get(Calendar.YEAR);
        int month = current.get(Calendar.MONTH) - date.get(Calendar.MONTH);
        int day = current.get(Calendar.DAY_OF_MONTH) - date.get(Calendar.DAY_OF_MONTH);
        
        if(month <0 || (month == 0 && day ==0)){
            year--;
            
        }result = year;
        
                return result;
        
    }
    public int GetYear(Calendar from , Calendar to){
        int result = 0;
        int year = to.get(Calendar.YEAR) - from.get(Calendar.YEAR);
        int month = to.get(Calendar.MONTH) - from.get(Calendar.MONTH);
        int day = to.get(Calendar.DAY_OF_MONTH) - from.get(Calendar.DAY_OF_MONTH);
        
        if(month <0 || (month == 0 && day ==0)){
            year--;
            result = year;
        }
        
                return result;
        
    }
    public void PrintDate(Calendar date , String format){
        SimpleDateFormat fmt = new SimpleDateFormat(format);
        Print(fmt.format(date.getTime()));
        
    }
    public Object ReadEnum(String title, String chooseMessage, Object[]enums) throws IOException{
        byte limit = (byte)enums.length;
        Println(title);
        String str = GetEnumValues(enums) + chooseMessage;
        byte result = ReadByte(str,( byte)1, limit);
        return enums [result-1];
    }
    private String GetEnumValues(Object[]enums){
        String result = "";
        byte i =1;
        for(Object o : enums){
            result +=1 + "." + o.toString() + "\n";
            i++;
    }return result;
        
        
    }
}
