package swpruebai;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.44E5A485-22DA-5015-2B54-CCB85802169B]
// </editor-fold> 
public enum TipoCategoria {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.30B004D9-B380-1D60-2D8F-5E9B2F51C88D]
    // </editor-fold> 
    MUSICA,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.272F4D03-6554-E194-C797-01E1FA1B78BD]
    // </editor-fold> 
    ENTRETEMIENTO,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.E70420E1-8EB7-A612-D280-20F3B82C54F2]
    // </editor-fold> 
    SOCIAL,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.1EB83C55-4553-3B94-6A5E-6F6017395484]
    // </editor-fold> 
    DEPORTES;


}

