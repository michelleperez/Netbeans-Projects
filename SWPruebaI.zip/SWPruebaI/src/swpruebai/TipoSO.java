package swpruebai;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.6CF9A8EA-5873-8A71-B7E5-5C1930670E62]
// </editor-fold> 
public enum TipoSO {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.FAA4950C-5D60-E563-1E67-A1217E24E8CB]
    // </editor-fold> 
    Android,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.6CEF66EC-6EA4-D1E2-B185-53C2D56D41A1]
    // </editor-fold> 
    iOS;


}

