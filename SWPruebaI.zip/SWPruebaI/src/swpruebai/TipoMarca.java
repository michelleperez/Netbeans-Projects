package swpruebai;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.3EEB0EDF-4087-DF50-FF12-F4E2BB121ABD]
// </editor-fold> 
public enum TipoMarca {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.BF57942D-5D59-C9A7-CBBA-D69231FA66FF]
    // </editor-fold> 
    Samsung,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.EE7269A3-3B37-DDB1-352A-EB6DAB2505F7]
    // </editor-fold> 
    Iphone,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.29FF6573-FAD7-3E9F-2D94-B2CA1F01DE85]
    // </editor-fold> 
    Lg;


}

