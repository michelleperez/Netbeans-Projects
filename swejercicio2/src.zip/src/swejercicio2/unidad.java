/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swejercicio2;

/**
 *
 * @author labctr
 */
public enum unidad {
    Unidad_1, Unidad_2, Unidad_3;
}
