package piitaller1;

public enum TipoTransaccion {
    Deposito, Retiro
}
