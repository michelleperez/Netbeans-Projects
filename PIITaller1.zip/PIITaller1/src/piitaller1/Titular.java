
package piitaller1;

public class Titular {
    private String nombre;
    private String cedula;
    
    public Titular(){
        
    }    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }      
    
}