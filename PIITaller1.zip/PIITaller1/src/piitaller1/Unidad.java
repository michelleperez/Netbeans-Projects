package piitaller1;

public enum Unidad {
    UnidadI, UnidadII, UnidadIII
    
    
}
