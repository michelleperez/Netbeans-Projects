
package piitaller1;

public enum TipoCuenta {
    Ahorros,Corriente, NA
}
