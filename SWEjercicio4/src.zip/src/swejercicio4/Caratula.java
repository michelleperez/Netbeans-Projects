/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swejercicio4;

/**
 *
 * @author labctr
 */
public class Caratula {
     private String titulo;
    private String materia;
    private String autor;
    private String fecha;
    private byte ejercicio;
    private String  unidad;
    private String descripcion;

    public Caratula() {
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public byte getEjercicio() {
        return ejercicio;
    }

    public void setEjercico(byte ejercico) {
        this.ejercicio = ejercico;
    }

    public String  getUnidad() {
        return unidad;
    }

    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    public void  Mostrar(){
        
        System.out.println(this. getTitulo());
        System.out.println(this.getMateria());
        System.out.println("Autor:" + this.autor);
        System.out.println(this.getFecha());
        System.out.println("Taller:" + this.ejercicio);
        System.out.println("Unidad:" + this.unidad);
        System.out.println("Descripcion:" + this.descripcion);
        
    }
    
}
