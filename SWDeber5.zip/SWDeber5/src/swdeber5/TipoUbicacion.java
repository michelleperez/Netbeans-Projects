package swdeber5;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.1EEFC457-EA5D-5BE7-F556-09497F509330]
// </editor-fold> 
public enum TipoUbicacion {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.D16272B2-5F85-50E5-7A53-9D97D219108B]
    // </editor-fold> 
    LOTE,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.07ACFBDA-11F8-A2BA-F0B0-F0ACB5D18C6A]
    // </editor-fold> 
    CRIPTA,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.5BFFC5B4-BEE0-BF55-B957-8D2BC3E4F18E]
    // </editor-fold> 
    URNA;


}

