package swdeber5;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.35D6BC88-306B-E430-0DBE-03CB5F8ED643]
// </editor-fold> 
public enum MetodoPago {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.44496057-8092-44DA-FBF7-E0B27A521E00]
    // </editor-fold> 
    Efectivo,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.5E8EA3E8-8C07-04D7-BFFB-04D2F6169049]
    // </editor-fold> 
    Dinero_Electronico,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.1E4A67C3-93A7-FDA5-A51B-B2566002566D]
    // </editor-fold> 
    Tarjeta_Credito,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.464CF708-9838-49DE-7571-891EE6E9E0D3]
    // </editor-fold> 
    Transferencia,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.A6D12EE3-7390-E180-AEFC-B07D31350DF7]
    // </editor-fold> 
    Tarjeta_Debito;


}

