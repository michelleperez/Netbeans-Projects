package swdeber5;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.DCFEAFDD-9A68-4AB9-E33E-C8C6421F3DAD]
// </editor-fold> 
public enum Estado {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.EB5E86BA-5AD7-DE7F-4C92-211D8BEEAAE5]
    // </editor-fold> 
    CENIZAS,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.B430A0B3-B9DA-0B97-1B7F-955A76988D90]
    // </editor-fold> 
    RESTOS,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.09BD2625-18D4-0C09-6C3B-9802EB073F71]
    // </editor-fold> 
    CUERPO_ENTERO;


}

