package swdeber5;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.43590950-1580-94FC-7C98-3610A02D5A12]
// </editor-fold> 
public enum TipoProducto {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.DF80F686-FCB5-62D7-56C1-17729A9BF364]
    // </editor-fold> 
    ARREGLO_FLORAL,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.126C00D3-8A9B-7518-2417-672BDE8C515B]
    // </editor-fold> 
    BEBIDAS,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.83299E04-518F-FFA0-4B41-4AAE88F8A4C3]
    // </editor-fold> 
    MUSICA,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.07C47409-C26E-7EF1-FEB1-A577746FB61C]
    // </editor-fold> 
    MISA,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.ECFC90DF-F733-C314-B3BB-4B50B2684917]
    // </editor-fold> 
    COMIDA,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.55EC8FC3-7AF1-47E5-15A8-966A75E43E0E]
    // </editor-fold> 
    RECUERDOS;


}

