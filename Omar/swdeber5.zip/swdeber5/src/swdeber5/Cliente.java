package swdeber5;

import java.util.Calendar;
import util.altamirano.*;

// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.846D529C-E740-3B6D-0A0B-F5A77EAFA608]
// </editor-fold> 
public class Cliente extends Persona {

    private util ut = new util();
    
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.6393045B-679A-C33C-9BE9-2DF130D8ED56]
    // </editor-fold> 
    private int numero;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.4C4FEFA4-12C2-1D3B-0C66-D3D912ACD720]
    // </editor-fold> 
    private Calendar fecha_afiliacion;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.3A8624E3-3FF4-C3E7-0884-CE881881E0CA]
    // </editor-fold> 
    public Cliente () {
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.D1E7C728-1F43-DA13-F473-656DB98E57C4]
    // </editor-fold> 
    public void Imprimir() {
    
        this.Mostrar();
        ut.Println("Numero: "+numero);
        ut.Print("Fecha de afilicion: ");
        ut.PrintDate(fecha_afiliacion, "dd/MMM/yyyy");
        ut.Println("");
        
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.657E40B8-4B30-F8F6-6E7E-5FF937D44C76]
    // </editor-fold> 
    public Calendar getFecha_afiliacion () {
        return fecha_afiliacion;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.6037145F-959F-F26E-9749-D4DD1AD575C6]
    // </editor-fold> 
    public void setFecha_afiliacion (Calendar val) {
        this.fecha_afiliacion = val;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.3447630B-3869-BDCA-B1BB-E4E86BDEA8FC]
    // </editor-fold> 
    public int getNumero () {
        return numero;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.403594DA-C87D-36B7-1193-909FB0AB27C8]
    // </editor-fold> 
    public void setNumero (int val) {
        this.numero = val;
    }

}

