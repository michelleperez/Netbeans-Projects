
package swdeber5;
import java.util.Calendar;
import java.util.Locale;
import util.altamirano.*;
/**
 *
 * @author omar
 */
public class Swdeber5 {

    private static util ut = new util();
    
    
    public static void main(String[] args) {
        
        try {
            Calendar fecha = Calendar.getInstance();
            fecha.set(2017, Calendar.JUNE,15);
            Unit unidad = Unit.II;
            
            ut.setTitle("Ejemplo de generalizacion");
            ut.setDescription("Uso de clases y UML");
            ut.setDate(fecha);
            ut.setUnit(unidad);
            
            ut.PrintHeader();
            
            
            ut.PrintFooter();
            
            
        } catch (Exception e) {
            ut.Println("Error, "+e);
            
            
        }
    }
    
}
