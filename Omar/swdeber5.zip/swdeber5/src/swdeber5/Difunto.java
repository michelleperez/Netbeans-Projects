package swdeber5;

import java.util.Calendar;
import util.altamirano.*;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.B637E743-8F24-3941-DEFE-7B5920CE2F58]
// </editor-fold> 
public class Difunto extends Persona {

    
    private util ut = new util();
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.9629A5F7-200D-6E49-7162-DE859016D8FD]
    // </editor-fold> 
    private Calendar fecha_defuncuin;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.E9F8C1FB-CF89-8B03-F3AC-6ABA0C1E29B5]
    // </editor-fold> 
    private String causa;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.43753E9D-54AD-0DC4-0CE6-F8E304EED9FE]
    // </editor-fold> 
    private Estado estado;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.92DA59EE-11D3-1C3A-87C2-23325EE518B2]
    // </editor-fold> 
    public Difunto () {
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.1271052B-1DE4-22BE-656A-D9AE7F6822DA]
    // </editor-fold> 
    public void Imprimir() {
        this.Mostrar();
        ut.Print("Fecha de defunccion: ");
        ut.PrintDate(fecha_defuncuin, "dd/MMM/yyyy");
        ut.Println("Causa: "+causa);
        ut.Println("Estado: "+estado);
        
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.13CC0168-BC74-C965-AF42-BE65F33D5AEC]
    // </editor-fold> 
    @Override//sobreescribe el metodo calcular edad de la clase persona
    public int CalcularEdad () {
        return ut.GetYears(this.getFecha_nacimiento(), fecha_defuncuin);
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.133B87DC-2E29-D3DC-A524-730ACC33710E]
    // </editor-fold> 
    public String getCausa () {
        return causa;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.3CBA67D2-FFD7-8125-C404-561B09C905CE]
    // </editor-fold> 
    public void setCausa (String val) {
        this.causa = val;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.341C8708-0081-5A29-A933-D0307676BD52]
    // </editor-fold> 
    public Estado getEstado () {
        return estado;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.40BA9E83-982B-9AF0-565A-C952A861C9A8]
    // </editor-fold> 
    public void setEstado (Estado val) {
        this.estado = val;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.6B73CBFA-B937-5397-8BA7-C78E95F4D0B6]
    // </editor-fold> 
    public Calendar getFecha_defuncuin () {
        return fecha_defuncuin;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.3882566E-0BB3-E34C-BCB4-A1D08483B7F0]
    // </editor-fold> 
    public void setFecha_defuncuin (Calendar val) {
        this.fecha_defuncuin = val;
    }

}

