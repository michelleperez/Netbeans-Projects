package swdeber5;

import java.util.Calendar;
import util.altamirano.*;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.96851F25-EC56-6A5A-AF8E-260A1F9998B2]
// </editor-fold> 
public class Persona {
    
    
    private util ut = new util();

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.868718EB-AF30-88D1-1ECD-84BA648C27B3]
    // </editor-fold> 
    private String nombre;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.632CBC3C-0EC5-1DCA-FEA5-CFEBFE0022D4]
    // </editor-fold> 
    private String cedula;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.7144B24B-2B49-BA3A-F25E-8730E38BF148]
    // </editor-fold> 
    private Calendar fecha_nacimiento;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.9B8A8267-AA54-ACFD-3EEA-EF70F1E916BE]
    // </editor-fold> 
    public Persona () {
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.F3A095F4-DFBF-C2C1-3273-39FBF7FCCF06]
    // </editor-fold> 
    public String getCedula () {
        return cedula;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.3A06D921-76D0-F3C8-B73C-54E88E1EE323]
    // </editor-fold> 
    public void setCedula (String val) {
        this.cedula = val;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.7F5E218E-3CBA-94A2-CE08-362DD2BFC298]
    // </editor-fold> 
    public Calendar getFecha_nacimiento () {
        return fecha_nacimiento;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.02179827-1C99-60ED-A308-D046FE39E56D]
    // </editor-fold> 
    public void setFecha_nacimiento (Calendar val) {
        this.fecha_nacimiento = val;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.620F28F5-DCDF-1E41-63BB-41DD7186A71E]
    // </editor-fold> 
    public String getNombre () {
        return nombre;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.A1E41C5D-82FD-A753-F983-6C056F415005]
    // </editor-fold> 
    public void setNombre (String val) {
        this.nombre = val;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.66ED3D44-A93C-08D0-CFC5-C25A0D0F13FD]
    // </editor-fold> 
    public void Mostrar () {
        ut.Println("Cédula: "+cedula);
        ut.Println("Nombre: "+nombre);
        ut.Print("Fecha de nacimiento: ");
        ut.PrintDate(fecha_nacimiento, "dd/MMM/yyyy");
        ut.Println("");
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.A65B3AFF-BC2F-3058-E13B-5A4D90828B24]
    // </editor-fold> 
    public int CalcularEdad () {
        return ut.GetYears(fecha_nacimiento);
    }

}

