package swdeber5;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.079C073F-7AF9-F46D-BD8B-9355BAFD9071]
// </editor-fold> 
public enum Estado {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.0A1929B7-2644-0458-D77A-437B0525340F]
    // </editor-fold> 
    CUERPO_ENTERO,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.EA5992FA-4836-BC20-34C9-6C577BA6749B]
    // </editor-fold> 
    RESTOS,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.28D54B8F-C3B7-CB37-8D11-8186B431318C]
    // </editor-fold> 
    CENIZAS;


}

