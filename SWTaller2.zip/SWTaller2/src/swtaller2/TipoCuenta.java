package swtaller2;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.75AE34E3-8FD6-A6C4-3BB7-D0E90470FA92]
// </editor-fold> 
public enum TipoCuenta {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.5D54D0EF-3C3A-8976-9332-508152869F40]
    // </editor-fold> 
    Ahorros,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.8A674CE8-8375-9A5A-20CD-78C66E58C34E]
    // </editor-fold> 
    Corriente;


}

