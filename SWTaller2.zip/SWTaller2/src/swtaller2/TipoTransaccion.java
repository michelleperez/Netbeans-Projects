package swtaller2;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.002A9370-DB29-FA5D-27C3-3797CD8B175C]
// </editor-fold> 
public enum TipoTransaccion {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.572CD5A5-E948-276B-4C69-06BD579D02A0]
    // </editor-fold> 
    Deposito,

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.925BC015-9119-5923-4D81-04AC87B11190]
    // </editor-fold> 
    Retiro,
    AperturaCuenta;

}

