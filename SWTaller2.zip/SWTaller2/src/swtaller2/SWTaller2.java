package swtaller2;
import java.io.IOException;
import util.perez.*;
import java.util.Calendar;
public class SWTaller2 {

         private static util utl = new util();
    public static void main(String[] args) throws IOException {
        try {
            // Instanciar objetos
   
        Persona per = new Persona();
        Transaccion tra = new Transaccion();
        Cuenta c = new Cuenta();
        
        
        Calendar date = Calendar.getInstance();
            date.set(2017,Calendar.JUNE,23);
            Unit unidad = Unit.II;
            utl.setDate(date);
            utl.setUnit(unidad);
            utl.setDescription("Implementación");
            utl.setTitle("Clases relacionadas Agregación/Composición");
            utl.setNumber((byte)2);
            utl.PrintHeader();
            
        //Ingresar datos titular / persona
        utl.Println("Ingresar datos del titular: ");
        per.setNombre(utl.ReadString("Nombre: "));
        per.setCedula(utl.ReadString("Cédula: "));
        per.setDireccion(utl.ReadString("Dirección: "));
        per.setTelefono(utl.ReadString("Teléfono: "));
       
        //Ingresar datos cuenta
        utl.Println("Ingrese datos de la cuenta");
        c.setNum_cuenta(utl.ReadString("Número:"));
        TipoCuenta tipoc = (TipoCuenta)utl.ReadEnum("Tipo de Cuenta","Elegir opción: ",TipoCuenta.values());
        c.setCuenta(tipoc);
        
        
       //Transacciones
        utl.Println("BIENVENIDO");
        byte op=0;
        do{
            
           utl.Println("Selección tipo de transacción:");
           TipoTransaccion tipo = (TipoTransaccion)utl.ReadEnum("Tipo de Transacción","Elegir opción: ",TipoTransaccion.values());
           tra.setTipo_trans(tipo);
            switch(op){
                    case 1:
                        utl.Print("Deposito");
                        double dou= utl.ReadDouble("Ingrese el monto: ");
                        c.Depositar(dou);                        
                        break;                    
                    case 2:   
                         utl.Print("Retiro");
                        dou = utl.ReadDouble("Ingrese el monto");
                        c.Retirar(dou);
                        break;
                    case 3:
                        utl.Print("Apertura de cuenta:");
                        dou = utl.ReadDouble("Ingresar $ 200 para apertura de cuenta: ");
                        c.AperturarCuenta(dou);
                        
                        break;
                                            
                }                
        }while(op != 3);
               
      
       per.Mostrar();
       c.Mostrar();
       c.MostrarTransacciones();
       utl.PrintFooter();
        
        } catch (Exception e) {
        }
 
        
    
       
        
    }
    
}
