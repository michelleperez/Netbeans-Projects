package swtaller2;
import java.util.Calendar;
import util.perez.*;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.64B668A8-F9B1-CE80-9CE5-2648CCA78DAC]
// </editor-fold> 
public class Persona {
 private static util utl = new util();
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.BACBBB5D-B75A-3CCF-839F-EBA530FAD0AE]
    // </editor-fold> 
    private String nombre;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.AFA10FF6-A3EF-1AB4-2B1C-862E50CD5B93]
    // </editor-fold> 
    private String cedula;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.4432C1B9-01BF-A953-2222-6580D668570A]
    // </editor-fold> 
    private String direccion;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.3A06CDED-12C2-89F8-F479-348068C94370]
    // </editor-fold> 
    private String telefono;

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.3999EF71-0C25-BC1F-298D-7F156F412E30]
    // </editor-fold> 
    public Persona () {
    }
     
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.48C59C98-5EBF-E0D0-8794-E53E16DC8D43]
    // </editor-fold> 
    public String getCedula () {
        return cedula;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.B6E2B6BD-53D8-F98D-6CA1-A35D11718529]
    // </editor-fold> 
    public void setCedula (String val) {
        this.cedula = val;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.15A0B545-35E9-0DF6-DC1E-0BB94DCEFBBD]
    // </editor-fold> 
    public String getDireccion () {
        return direccion;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.10BD2BE4-8DA8-3FC1-922C-5220AC2585F1]
    // </editor-fold> 
    public void setDireccion (String val) {
        this.direccion = val;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.E5291CE4-5D7A-1744-1851-EDEA71E4DFA0]
    // </editor-fold> 
    public String getNombre () {
        return nombre;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.910BEB6E-BEB3-418E-EA6C-E87263A161F6]
    // </editor-fold> 
    public void setNombre (String val) {
        this.nombre = val;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.CB9F950D-03B8-9038-4C1E-3E1AB8B766CE]
    // </editor-fold> 
    public String getTelefono () {
        return telefono;
    }

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,regenBody=yes,id=DCE.31A389E9-9D92-F674-E87B-04019A6D3D53]
    // </editor-fold> 
    public void setTelefono (String val) {
        this.telefono = val;
    }


    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.F220EB38-2C00-EA3D-A779-B73D00AC82DD]
    // </editor-fold> 
    public void Mostrar () {
        utl.Println("\n=================================================================================================================");
       utl.Println("\tTitular:" +nombre+"\tCédula:" +cedula);
        utl.Println("\tDirección:" +direccion+"\tTeléfono:" +telefono);
    }

}

