package swejercicio8;


// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.486E662F-597F-43E3-AD6C-88DEED6BE5AA]
// </editor-fold> 
public interface FiguraGeometrica {

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.A044050F-F58E-B069-AB3D-4F60AA1D2328]
    // </editor-fold> 
    public float CalcularArea ();

    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.3387E4D3-110D-4979-AD8D-B0D91FD82581]
    // </editor-fold> 
    public float CalcularPerimetro ();

}

